package assignmet1;

public class Start_up {
	
	public static void main(String[] args) {

		ThriftyRentSystem user = new ThriftyRentSystem();
		
        user.displayMenu();
	}

}

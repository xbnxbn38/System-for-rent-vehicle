package model.constant;

public interface VehicleType {
	public static final String CAR="car";
	public static final String VAN="van";
}

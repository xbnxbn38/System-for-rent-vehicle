package model.exception;

public class PerformMaintenanceException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = -1151071425561399610L;

	public PerformMaintenanceException() {

	}

	public PerformMaintenanceException(String arg0) {
		super(arg0);
	}
	
}

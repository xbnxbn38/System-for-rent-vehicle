package model.exception;

public class ReturnException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2167746995277921323L;

}
